//This is one possible solution to question #22. 
//Technically, your solution does not need an explicit constructor.

import java.util.ArrayList;

public class FruitBasket<T>{
  private ArrayList<T> contents = new ArrayList<>();
  private int maxCap;
  private String shape;
  private boolean hasFlies;

  public void emptyBasket(){
    contents = new ArrayList<T>();
  }

  public void replaceFruit(ArrayList<T> contents){
    this.contents = contents;
  }

  public String toString(){
    if(contents.size()==0)
      return "This fruit basket contains 0 pieces of fruit and is empty";
    else
      return "This fruit basket contains " + contents.size() + " pieces of fruit and is not empty";
  }
}