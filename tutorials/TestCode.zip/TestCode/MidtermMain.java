//You can use this main method to try out your solutions to the test questions.

import java.util.ArrayList;

public class MidtermMain {

  public static void main(String[] args){

  Fruit v1 = new Fruit("first fruit");
  Fruit v2 = new Apple(1, "Macintosh");
  Apple v3 = new Apple(2, "Fuji");
  Apple v4 = (Apple)v2;
  Fruit v5 = v3;
  int a = 5;
  int b = 5;
  Integer x = new Integer(5);
  Integer y = new Integer(5);

  System.out.println(v2.name);
  System.out.println(v3.name);
  System.out.println(v2.numFruit);
  System.out.println(v3.numFruit);
  System.out.println(v1.getNumFruit());
  System.out.println(v1.getName());
  System.out.println(v2.getNumFruit());
  System.out.println(v2.getName());
  System.out.println(v3.getNumFruit());
  System.out.println(v3.getName());
  System.out.println(Apple.pickFruit(v3));
  //System.out.println(Fruit.pick(v1));
  System.out.println(Fruit.pick(v4));
  System.out.println(v3.getCanGrow());
  System.out.println(v2.equals(v4));
//
  System.out.println(a == b);
  System.out.println(x == y);
  //System.out.println(a.equals(x));
  System.out.println(x.equals(a));
  System.out.println(x.equals(y));
//
  FruitBasket<Apple> f = new FruitBasket<Apple>();
  ArrayList<Apple> al = new ArrayList<Apple>();
  al.add(v3);
  f.replaceFruit(al);
  System.out.println(f);


  }

}