package university;

public interface IDed<T> {
    
    public T getID();

}